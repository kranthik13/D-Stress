import sys
import time
import joblib
import smtplib
import numpy as np
import pandas as pd
from flask import request, jsonify, Flask
from flask_cors import CORS, cross_origin
import warnings
warnings.simplefilter('ignore')

app = Flask(__name__)

def convert_to_string(x):
    x = str(x).replace('"', '')
    return x

def init():
    global data, model, feat, target, encoded_data, reject_p_cut, accept_p_cut, mailer, mail_username, mail_password

    target = 'treatment'
    data = pd.read_csv("../data/full_data.csv")
    encoded_data = pd.read_csv("../data/full_data_encoded.csv")
    model = joblib.load("../saved_models/lgb_model_1.sav")
    feat = data.columns.tolist()
    feat.remove(target)
    feat.remove("s.no")
    feat.remove("emp_id")
    feat.remove("email_id")

    reject_p_cut = 0.4
    accept_p_cut = 0.6

    mailer = smtplib.SMTP('smtp.gmail.com', 587)
    mailer.starttls()
    mail_username = "library.reissuer@gmail.com"
    mail_password = "aitoss123"

    try:
        mailer.login(mail_username, mail_password)
    except smtplib.SMTPAuthenticationError:
        print("Wrong GMail Password.")
        sys.exit()
    print("SMTP Connected.")


def take_decision(prob):
    if prob < reject_p_cut:
        return "Reject / Red"
    elif prob < accept_p_cut:
        return "HR Call / Yellow"
    else:
        return "Accept / Green"


@app.route('/test', methods=['GET'])
def test():
    result = {
        "treatment_probability": np.nan,
        "decision": np.nan,
        "error_code": 0
    }
    if request.method == 'GET':
        id = convert_to_string(request.args.get('empid'))
        if encoded_data[encoded_data['emp_id'] == id].shape[0] == 0:
            result['error_code'] = "Employee ID not available"  # Employee ID not available
            return jsonify(result)
        polarity = encoded_data['comments_polarity'][encoded_data['emp_id'] == id].values[0]
        if polarity < -0.2:
            treatment_probability = 1
        else:
            test_data = encoded_data[feat][encoded_data['emp_id'] == id].values
            treatment_probability = model.predict(test_data)[0]

        result['treatment_probability'] = treatment_probability
        result['decision'] = take_decision(treatment_probability)
        result['error_code'] = 0
        return jsonify(result)
    else:
        result['error_code'] = "Only GET request allowed."
    return jsonify(result)


def send_mail(emp_id, email_id, package_number):
    packages_description = {
        "1": ["Meditation Classes", "1 Week"],
        "2": ["Professional Counselling Sessions", "3 Sessions"],
        "3": ["Spa Session", "2 Visits"],
        "4": ["Resort Retreat", "4 Days"],
    }
    option_dict = {
        'approval': 'Greetings "{}",\n\n\nYou are one of our lucky employee who has been selected for "{}" stress-relief package for'
                    ' "{}" which can be availed this month i.e "September 2019".\n\nWe hope you enjoy the benefits provided and come back rejuvenated and stress-free. '
                    '\n\n\nThanks and Regards\nHR Manager\ndumb_terminals',
    }
    TEXT = option_dict["approval"].format(emp_id, packages_description[package_number][0], packages_description[package_number][1])
    message = 'Subject: {}\n\n{}'.format("Stress Relief Benefits", TEXT)
    mailer.sendmail(mail_username, email_id, message)
    print("Mail Sent.\n")


@app.route('/mail_approval', methods=['GET'])
def mail_approval():
    result = {
        "sent": False,
        "error_code": 0
    }

    if request.method == 'GET':
        id = convert_to_string(request.args.get('empid'))
        package_number = convert_to_string(request.args.get('package_number'))
        print(id, package_number)
        if data[data['emp_id'] == id].shape[0] == 0:
            result['error_code'] = "Employee ID Not Available"
            return jsonify(result)
        test_mail_id = data['email_id'][data['emp_id'] == id].values[0]
        send_mail(id, test_mail_id, package_number)
        result['sent'] = True
        result['error_code'] = 0
        return jsonify(result)
    else:
        result['error_code'] = "Only GET request allowed."
    return jsonify(result)


if __name__ == "__main__":
    init()
    CORS(app)
    app.run(host='0.0.0.0', port=5000, debug=True)
