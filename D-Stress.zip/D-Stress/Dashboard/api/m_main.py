import joblib
import numpy as np
import pandas as pd
from flask import request, jsonify, Flask
from flask_cors import CORS, cross_origin
import warnings
warnings.simplefilter('ignore')

app = Flask(__name__)


def init():
    global data, model, feat, target, reject_p_cut, accept_p_cut

    target = 'treatment'
    data = pd.read_csv("../data/full_data.csv")
    model = joblib.load("../saved_models/lgb_model_1.sav")
    feat = data.columns.tolist()
    feat.remove("emp_id")
    feat.remove(target)

    reject_p_cut = 0.4
    accept_p_cut = 0.6


def take_decision(prob):
    if prob < reject_p_cut:
        return "Reject / Red"
    elif prob < accept_p_cut:
        return "HR Call / Yellow"
    else:
        return "Accept / Green"


@app.route('/test', methods=['GET'])
def test():
    result = {
        "treatment_probability": np.nan,
        "decision": np.nan,
        "error_code": 0
    }

    if request.method == 'GET':

        print(request.args.get('empid'))

        id = request.args.get('empid')
        id = str(id).replace('"', '')
        print(id)
        print(data[data['emp_id'] == id])
        if data[data['emp_id'] == id].shape[0] == 0:
            result['error_code'] = "100"  # Employee ID not available
            return jsonify(result)

        test_data = data[feat][data['emp_id'] == id].values
        treatment_probability = model.predict(test_data)[0]
        result['treatment_probability'] = treatment_probability
        result['decision'] = take_decision(treatment_probability)
        result['error_code'] = 0

        return jsonify(result)
    else:
        result['error_code'] = "Only POST request allowed."

    return jsonify(result)


if __name__ == "__main__":
    init()
    CORS(app)
    app.run(host='0.0.0.0', port=5000, debug=True)
