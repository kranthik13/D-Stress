 $(document).ready(function(){
    $('.side-bar-overlay').on('click',function(){
        $('.side-bar').removeClass('small-screen');
        $(this).removeClass('sidebar-overlay-new');
    });
    $('.ion-lg').on('click',function(e){
        e.preventDefault();
        $('.side-bar').toggleClass('side-bar-half');
        $('.navbar-brand').toggleClass('navbar-none');
        $('.side-bar').removeClass('small-screen');
        $(this).toggleClass('ion-lg-new');
    });
    $('.ion-sm').on("click",function(){
    	$('.side-bar').addClass('small-screen');
    	$('.side-bar-overlay').addClass('sidebar-overlay-new');
    	$('.side-bar').removeClass('side-bar-half');
    });
    $(window).resize(function(){
       if ($(window).width() >= 700) {  
            $('.side-bar').removeClass('small-screen');
            $('.side-bar-overlay').removeClass('sidebar-overlay-new');
            if($('.side-bar').width() === 245){
                $('.ion-lg').removeClass('ion-lg-new');
                $('.navbar-brand').removeClass('navbar-none');
            }
        }     
    });
  $(".search").keyup(function () {
    var searchTerm = $(".search").val();
    var listItem = $('.results tbody').children('tr');
    var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
    
  $.extend($.expr[':'], {'containsi': function(elem, i, match, array){
        return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
    }
  });
    
  $(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','false');
  });

  $(".results tbody tr:containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','true');
  });

  var jobCount = $('.results tbody tr[visible="true"]').length;
    $('.counter').text(jobCount + ' item');

  if(jobCount == '0') {$('.no-result').show();}
    else {$('.no-result').hide();}
		  });

    // the selector will match all input controls of type :checkbox
// and attach a click event handler 
$("input:radio").on('click', function() {
  // in the handler, 'this' refers to the box clicked on
  var $box = $(this);
  if ($box.is(":checked")) {
    // the name of the box is retrieved using the .attr() method
    // as it is assumed and expected to be immutable
    var group = "input:radio[name='" + $box.attr("name") + "']";
    // the checked state of the group/box on the other hand will change
    // and the current value is retrieved using .prop() method
    $(group).prop("checked", false);
    $box.prop("checked", true);
  } else {
    $box.prop("checked", false);
  }
});


});
